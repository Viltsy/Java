import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.JList;
import javax.swing.JSpinner;
import javax.swing.JSlider;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JScrollPane;
import javax.swing.JProgressBar;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.TextArea;
import java.awt.Toolkit;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JToolBar;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.JMenuItem;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.DropMode;
import java.awt.Scrollbar;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JToggleButton;
import javax.swing.JCheckBox;
import javax.swing.ImageIcon;
import java.awt.event.AdjustmentListener;
import java.awt.event.AdjustmentEvent;
import java.awt.ScrollPane;
import java.awt.Panel;

@SuppressWarnings("unused")
public class GUI extends JFrame {

	
	private static final long serialVersionUID = 1L;
	/**
	 * JPanel ja sen nimi mihin kaikki on yhdistetty
	 */
	private JPanel contentPane;
	/**
	 * Pelin tekstit tulostetaan t�h�n siin� ei ole vertikaalista scrollbaria.
	 */
	private static TextArea textArea = new TextArea("", 0, 0, TextArea.SCROLLBARS_VERTICAL_ONLY);

	
	/**
	 * Muutettava teksti t�ss� tapauksessa se on Kirjoita haluamasi nimi:
	 */
	private static JLabel textPane = new JLabel();
	/**
	 * M��ritell��n tapahtumien valikko esim. Taso 1, Valitse haluamasi luokka jne.
	 */
	private static JLabel textPane_1 = new JLabel();
	
	/**
	 * Miekkaseikkailu logon label
	 */
	private static JLabel lblNewLabel = new JLabel();
	/**
	 * Ritarin taustakuva label
	 */
	private static JLabel lblNewLabel_1 = new JLabel();
	/**
	 * Taikurin taustakuva label
	 */
	private static JLabel lblNewLabel_2 = new JLabel();
	/**
	 * Jousimiehen taustakuva label
	 */
	private static JLabel lblNewLabel_3 = new JLabel();
	/**
	 * Ensimm�inen button k�ytet��n valinnoissa
	 */
	private static JButton btnNewButton_1 = new JButton("Taikuri - 100 HP");
	/**
	 * Toinen button k�ytet��n valinnoissa
	 */
	private static JButton btnNewButton_2 = new JButton("Jousimies - 150 HP");
	/**
	 * Kolmas button k�ytet��n valinnoissa
	 */
	private static JButton btnNewButton = new JButton("Ritari - 200 HP");
	/**
	 * Nelj�s button k�ytet��n valinnoissa
	 */
	private static JButton button = new JButton("Mahdoton");
	/**
	 * Viides button k�ytet��n vahvistuksessa
	 */
	private static JButton btnNewButton_3 = new JButton("Hyv�ksy valinta");
	
	/**
	 * T�h�n k�ytt�j� kirjoittaa haluamansa nimen.
	 */
	private JTextField textField;
	
	/**
	 * Launch the application.
	 * @param args p��ohjelman parametri.
	 */
	public static void main(String[] args) {
	
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		MiekkaseikkailuV2.main(args);
	}
	
	/** GUI konstruktori <br><br>
	 * K�ytt�liittym�n konstruktori
	 */
	public GUI() {
		setBackground(new Color(0, 0, 0));
		setTitle("Miekkaseikkailu");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1587, 999);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(new Color(255, 255, 255));
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Valikko");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmOhjeet = new JMenuItem("Ohjeet");
		mntmOhjeet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			tulosta("\n\nPeliss� on 10 tasoa, joissa kerrotaan tasokuvaus ja sinulta kysyt��n t�h�n tasovalintaa painikkeiden avulla\nPelin aikana \"POSITIIVISET\" valinnat kasvattavat HP:tasi...\n\"NEGATIIVISET\" valinnat v�hent�v�t HP:ta riippuen siit� mink� vaikeustason valitset...\n\"NEUTRAALEISTA\" valinnoista et menet� HP:ta...\nValintasi j�lkeen peli kertoo sinulle mit� valinnasta tapahtuu..\nJos sinulla on viel� HP:ta j�ljell� jatkat seuraavalle tasolle...\nPelin viimeinen taso on 10 ja jos l�p�iset sen, voitat pelin...\n\nValitse luokka valintasi, kun olet valmis aloittamaan muista, ett� jokainen luokka on uniikki...\nT�m�n j�lkeen valitse haluamasi vaikeustaso jonka j�lkeen peli alkaa.\n\nPeliss� on my�s satuinnaisia tapahtumia, joten varaudu niihin");
			}
		});
		mnNewMenu.add(mntmOhjeet);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		textArea.setEditable(false);
		textArea.setForeground(Color.WHITE);
		textArea.setFont(new Font("Lucida Console", Font.PLAIN, 22));
		textArea.setBackground(new Color(0, 0, 0));
		textArea.setBounds(213, 267, 1202, 332);
		contentPane.add(textArea);
		textPane_1.setForeground(new Color(255, 255, 255));
		
		
		textPane_1.setFont(new Font("Old English Text MT", Font.PLAIN, 31));
		textPane_1.setBounds(23, 199, 502, 47);
		contentPane.add(textPane_1);
		
		JLabel lblHP = new JLabel("HP: ");
		lblHP.setFont(new Font("Eras Light ITC", Font.BOLD, 23));
		lblHP.setForeground(Color.RED);
		lblHP.setBounds(24, 105, 168, 36);
		contentPane.add(lblHP);
		
		JLabel lblKulta = new JLabel("Kulta: ");
		lblKulta.setForeground(new Color(238, 232, 170));
		lblKulta.setFont(new Font("Eras Light ITC", Font.BOLD, 23));
		lblKulta.setBounds(24, 152, 365, 36);
		contentPane.add(lblKulta);
		
		JLabel lblLuokka = new JLabel("Luokka: ");
		lblLuokka.setForeground(Color.WHITE);
		lblLuokka.setFont(new Font("Eras Light ITC", Font.BOLD, 23));
		lblLuokka.setBounds(24, 58, 382, 36);
		contentPane.add(lblLuokka);
		
		JLabel lblNimi = new JLabel("");
		lblNimi.setForeground(Color.WHITE);
		lblNimi.setFont(new Font("Eras Light ITC", Font.BOLD, 23));
		lblNimi.setBounds(24, 11, 513, 36);
		contentPane.add(lblNimi);
		
		textField = new JTextField();
		textField.setFont(new Font("Segoe UI Black", Font.PLAIN, 21));
		textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String nimi = textField.getText();
			Hahmo.setNimi(nimi);
			lblNimi.setText("Nimi: " + nimi);
			if (nimi != null) {
			textField.setVisible(false);
			textPane.setVisible(false);
			}
			}
		});
		textField.setBounds(329, 11, 525, 43);
		contentPane.add(textField);
		textField.setColumns(10);
		textPane.setForeground(Color.WHITE);
		textPane.setFont(new Font("Old English Text MT", Font.PLAIN, 28));
		
		textPane.setBounds(24, 11, 408, 43);
		contentPane.add(textPane);
		
		
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Malgun Gothic", Font.PLAIN, 16));
		btnNewButton.setBackground(new Color(0, 139, 139));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			if (textPane_1.getText().equals("Haluatko yritt�� uudestaan?")) {
					teksti�("Valitse haluamasi luokka");
					System.out.println("K�ynnistet��n ohjelma uudelleen...");
					MiekkaseikkailuV2.lopetusvalinta1();
			}
				
			if (textPane_1.getText().equals("Taso 10")) {
					System.out.println("valinta 1 Tasolta 10");
					MiekkaseikkailuV2.taso10valinta1();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
					MiekkaseikkailuV2.lopetus();
			}
			if (textPane_1.getText().equals("Taso 9")) {
					System.out.println("valinta 1 Tasolta 9");
					MiekkaseikkailuV2.taso9valinta1();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
				
					MiekkaseikkailuV2.taso10();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
						}
					
			}
			if (textPane_1.getText().equals("Taso 8")) {
					System.out.println("valinta 1 Tasolta 8");
					MiekkaseikkailuV2.taso8valinta1();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
				
					MiekkaseikkailuV2.taso9();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
						}
					
			}
			if (textPane_1.getText().equals("Taso 7")) {
					System.out.println("valinta 1 Tasolta 7");
					MiekkaseikkailuV2.taso7valinta1();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
				
					MiekkaseikkailuV2.taso8();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
						}
					
			}
			if (textPane_1.getText().equals("Taso 6")) {
			System.out.println("valinta 1 Tasolta 6");
			MiekkaseikkailuV2.taso6valinta1();
			lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
			lblKulta.setText("Kulta: " + Hahmo.getKulta());
		
			MiekkaseikkailuV2.taso7();
			if (MiekkaseikkailuV2.HP > 0) {
				MiekkaseikkailuV2.arvo();
				lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
				lblKulta.setText("Kulta: " + Hahmo.getKulta());
				}
			}
			if (textPane_1.getText().equals("Taso 5")) {
			System.out.println("valinta 1 Tasolta 5");
			MiekkaseikkailuV2.taso5valinta1();
			lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
			lblKulta.setText("Kulta: " + Hahmo.getKulta());
	
			MiekkaseikkailuV2.taso6();
			if (MiekkaseikkailuV2.HP > 0) {
				MiekkaseikkailuV2.arvo();
				lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
				lblKulta.setText("Kulta: " + Hahmo.getKulta());
				}
			
			}
			if (textPane_1.getText().equals("Taso 4")) {
					System.out.println("valinta 1 Tasolta 4");
					MiekkaseikkailuV2.taso4valinta1();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
			
					MiekkaseikkailuV2.taso5();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
						}
					
			}
			if (textPane_1.getText().equals("Taso 3")) {
				System.out.println("valinta 1 Tasolta 3");
				MiekkaseikkailuV2.taso3valinta1();
				lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
				lblKulta.setText("Kulta: " + Hahmo.getKulta());
			
				MiekkaseikkailuV2.taso4();
				if (MiekkaseikkailuV2.HP > 0) {
					MiekkaseikkailuV2.arvo();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
					}
				
			}
			if (textPane_1.getText().equals("Taso 2")) {
				System.out.println("valinta 1 Tasolta 2");
				MiekkaseikkailuV2.taso2valinta1();
				lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
				lblKulta.setText("Kulta: " + Hahmo.getKulta());
				MiekkaseikkailuV2.taso3();
				if (MiekkaseikkailuV2.HP > 0) {
					MiekkaseikkailuV2.arvo();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
					}
				
				}
			if (textPane_1.getText().equals("Taso 1")) {
				System.out.println("valinta 1 Tasolta 1");
				MiekkaseikkailuV2.taso1valinta1();
				lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
				lblKulta.setText("Kulta: " + Hahmo.getKulta());
				MiekkaseikkailuV2.taso2();
				if (MiekkaseikkailuV2.HP > 0) {
					MiekkaseikkailuV2.arvo();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
				}
				
			}	
			if (textPane_1.getText().equals("Valitse haluamasi vaikeustaso")) {
				MiekkaseikkailuV2.setVaikeustaso(1);
				GUI.tulosta("\n\nHaluat siis Helpon pelin? Tykk��t siis enemm�n pelin jounesta kuin vaikeudesta?");
				System.out.println("Vaikestaso on: " + MiekkaseikkailuV2.getVaikeustaso());
			}		
		
			if (textPane_1.getText().equals("Valitse haluamasi luokka")) {
			MiekkaseikkailuV2.hahmovalinta1();
			lblLuokka.setText("Luokka: " + Hahmo.getLuokka());
			lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
			lblKulta.setText("Kulta: " + Hahmo.getKulta());
			}
			
			if (Hahmo.getLuokka().equals("Ritari")) {
			lblNewLabel_2.setVisible(false);
			lblNewLabel_3.setVisible(false);
			lblNewLabel_1.setVisible(true);
			}
			}
		});
		btnNewButton.setBounds(450, 612, 634, 47);
		contentPane.add(btnNewButton);
		
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			if (textPane_1.getText().equals("Haluatko yritt�� uudestaan?")) {
				MiekkaseikkailuV2.lopetusvalinta2();
			}
		
			if (textPane_1.getText().equals("Taso 10")) {
					System.out.println("valinta 2 Tasolta 10");
					MiekkaseikkailuV2.taso10valinta2();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
					MiekkaseikkailuV2.lopetus();
			}
			if (textPane_1.getText().equals("Taso 9")) {
					System.out.println("valinta 2 Tasolta 9");
					MiekkaseikkailuV2.taso9valinta2();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
			
					MiekkaseikkailuV2.taso10();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
						}
					
			}
			if (textPane_1.getText().equals("Taso 8")) {
					System.out.println("valinta 2 Tasolta 8");
					MiekkaseikkailuV2.taso8valinta2();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
				
					MiekkaseikkailuV2.taso9();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
						}
					
			}
			if (textPane_1.getText().equals("Taso 7")) {
					System.out.println("valinta 2 Tasolta 7");
					MiekkaseikkailuV2.taso7valinta2();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
			
					MiekkaseikkailuV2.taso8();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
						}
					
			}
			if (textPane_1.getText().equals("Taso 6")) {
					System.out.println("valinta 2 Tasolta 6");
					MiekkaseikkailuV2.taso6valinta2();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
			
					MiekkaseikkailuV2.taso7();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
						}
					
			}
			if (textPane_1.getText().equals("Taso 5")) {
					System.out.println("valinta 2 Tasolta 5");
					MiekkaseikkailuV2.taso5valinta2();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
			
					MiekkaseikkailuV2.taso6();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
						}
					
			}
			if (textPane_1.getText().equals("Taso 4")) {
					System.out.println("valinta 2 Tasolta 4");
					MiekkaseikkailuV2.taso4valinta2();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
			
					MiekkaseikkailuV2.taso5();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
					}
			
			}
			if (textPane_1.getText().equals("Taso 3")) {
					System.out.println("valinta 2 Tasolta 3");
					MiekkaseikkailuV2.taso3valinta2();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
			
					MiekkaseikkailuV2.taso4();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
						}
					
			}
			if (textPane_1.getText().equals("Taso 2")) {
				System.out.println("valinta 2 Tasolta 2");
				MiekkaseikkailuV2.taso2valinta2();
				lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
				lblKulta.setText("Kulta: " + Hahmo.getKulta());
		
				MiekkaseikkailuV2.taso3();
				if (MiekkaseikkailuV2.HP > 0) {
					MiekkaseikkailuV2.arvo();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
					}
				
				}
			if (textPane_1.getText().equals("Taso 1")) {
				System.out.println("valinta 2 Tasolta 1");
				MiekkaseikkailuV2.taso1valinta2();
				lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
				lblKulta.setText("Kulta: " + Hahmo.getKulta());
		
				MiekkaseikkailuV2.taso2();
				if (MiekkaseikkailuV2.HP > 0) {
					MiekkaseikkailuV2.arvo();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
				}
				
			}
				
			if (textPane_1.getText().equals("Valitse haluamasi vaikeustaso")) {
				MiekkaseikkailuV2.setVaikeustaso(2);
				tulosta("\n\nHaluat siis Keskivaikean pelin? Oletko varma?");
				System.out.println("Vaikestaso on: " + MiekkaseikkailuV2.getVaikeustaso());
			}
	
			if (textPane_1.getText().equals("Valitse haluamasi luokka")) {
			MiekkaseikkailuV2.hahmovalinta2();
			lblLuokka.setText("Luokka: " + Hahmo.getLuokka());
			lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
			lblKulta.setText("Kulta: " + Hahmo.getKulta());
			}	
			if (Hahmo.getLuokka().equals("Taikuri")) {
			lblNewLabel_1.setVisible(false);
			lblNewLabel_3.setVisible(false);
			lblNewLabel_2.setVisible(true);
			}
			}
		});
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setFont(new Font("Malgun Gothic Semilight", Font.PLAIN, 16));
		btnNewButton_1.setBackground(new Color(0, 128, 128));
		btnNewButton_1.setBounds(450, 670, 634, 47);
		contentPane.add(btnNewButton_1);
		
		
		btnNewButton_2.setForeground(new Color(255, 255, 255));
		btnNewButton_2.setFont(new Font("Malgun Gothic Semilight", Font.PLAIN, 16));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			if (textPane_1.getText().equals("Taso 10")) {
					System.out.println("valinta 3 Tasolta 10");
					MiekkaseikkailuV2.taso10valinta3();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
					MiekkaseikkailuV2.lopetus();
			}
			if (textPane_1.getText().equals("Taso 9")) {
					System.out.println("valinta 3 Tasolta 9");
					MiekkaseikkailuV2.taso9valinta3();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
					MiekkaseikkailuV2.taso10();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
						}		
			}
			if (textPane_1.getText().equals("Taso 8")) {
					System.out.println("valinta 3 Tasolta 8");
					MiekkaseikkailuV2.taso8valinta3();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
					MiekkaseikkailuV2.taso9();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
					}
				
			}
			if (textPane_1.getText().equals("Taso 7")) {
					System.out.println("valinta 3 Tasolta 7");
					MiekkaseikkailuV2.taso7valinta3();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
					MiekkaseikkailuV2.taso8();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
						}
					
			}
			if (textPane_1.getText().equals("Taso 6")) {
					System.out.println("valinta 3 Tasolta 6");
					MiekkaseikkailuV2.taso6valinta3();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
					MiekkaseikkailuV2.taso7();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
					}
					
			}
			if (textPane_1.getText().equals("Taso 5")) {
					System.out.println("valinta 3 Tasolta 5");
					MiekkaseikkailuV2.taso5valinta3();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
					MiekkaseikkailuV2.taso6();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
					}
					
			}
			if (textPane_1.getText().equals("Taso 4")) {
					System.out.println("valinta 3 Tasolta 4");
					MiekkaseikkailuV2.taso4valinta3();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
					MiekkaseikkailuV2.taso5();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
					}
					
			}
			if (textPane_1.getText().equals("Taso 3")) {
					System.out.println("valinta 3 Tasolta 3");
					MiekkaseikkailuV2.taso3valinta3();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
					MiekkaseikkailuV2.taso4();
					if (MiekkaseikkailuV2.HP > 0) {
						MiekkaseikkailuV2.arvo();
						lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
						lblKulta.setText("Kulta: " + Hahmo.getKulta());
					}
					
			}
			if (textPane_1.getText().equals("Taso 2")) {
				System.out.println("valinta 3 Tasolta 2");
				MiekkaseikkailuV2.taso2valinta3();
				lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
				lblKulta.setText("Kulta: " + Hahmo.getKulta());
				MiekkaseikkailuV2.taso3();
				if (MiekkaseikkailuV2.HP > 0) {
					MiekkaseikkailuV2.arvo();
					lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
					lblKulta.setText("Kulta: " + Hahmo.getKulta());
				}
				
				}
			if (textPane_1.getText().equals("Taso 1")) {
				System.out.println("valinta 3 Tasolta 1");
				MiekkaseikkailuV2.taso1valinta3();
				lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
				lblKulta.setText("Kulta: " + Hahmo.getKulta());
				MiekkaseikkailuV2.taso2();
				if (MiekkaseikkailuV2.HP > 0) {
				MiekkaseikkailuV2.arvo();
				lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
				lblKulta.setText("Kulta: " + Hahmo.getKulta());
				}
			}
			if (textPane_1.getText().equals("Valitse haluamasi vaikeustaso")) {
				MiekkaseikkailuV2.setVaikeustaso(3);
				tulosta("\n\nHaluat siis Vaikean pelin? Oletko aivan varma");
				System.out.println("Vaikestaso on: " + MiekkaseikkailuV2.getVaikeustaso());
			}
		
			if (textPane_1.getText().equals("Valitse haluamasi luokka")) {
			MiekkaseikkailuV2.hahmovalinta3();
	
			lblLuokka.setText("Luokka: " + Hahmo.getLuokka());
			lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
			lblKulta.setText("Kulta: " + Hahmo.getKulta());
			}		
			
			if (Hahmo.getLuokka().equals("Jousimies")) {
				lblNewLabel_2.setVisible(false);
				lblNewLabel_1.setVisible(false);
				lblNewLabel_3.setVisible(true);
			}

			}
		});
		btnNewButton_2.setBackground(new Color(0, 128, 128));
		btnNewButton_2.setBounds(450, 731, 634, 47);
		contentPane.add(btnNewButton_2);
		
		
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
	
			if (textPane_1.getText().equals("Taso 8")) {
			System.out.println("valinta 4 Tasolta 8");
			MiekkaseikkailuV2.taso8valinta4();
			lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
			lblKulta.setText("Kulta: " + Hahmo.getKulta());
			MiekkaseikkailuV2.taso9();
			if (MiekkaseikkailuV2.HP > 0) {
				MiekkaseikkailuV2.arvo();
				lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
				lblKulta.setText("Kulta: " + Hahmo.getKulta());
			}
			}
			
			if (textPane_1.getText().equals("Taso 6")) {
			System.out.println("valinta 4 Tasolta 6");
			MiekkaseikkailuV2.taso6valinta4();
			lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
			lblKulta.setText("Kulta: " + Hahmo.getKulta());
			MiekkaseikkailuV2.taso7();
			if (MiekkaseikkailuV2.HP > 0) {
				MiekkaseikkailuV2.arvo();
				lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
				lblKulta.setText("Kulta: " + Hahmo.getKulta());
				}
			
			}
			if (textPane_1.getText().equals("Taso 5")) {
			System.out.println("valinta 4 Tasolta 5");
			MiekkaseikkailuV2.taso5valinta4();
			lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
			lblKulta.setText("Kulta: " + Hahmo.getKulta());
			MiekkaseikkailuV2.taso6();
			if (MiekkaseikkailuV2.HP > 0) {
				MiekkaseikkailuV2.arvo();
				lblHP.setText("HP: " + MiekkaseikkailuV2.HP);
				lblKulta.setText("Kulta: " + Hahmo.getKulta());
			}
			
			}
			else if (textPane_1.getText().equals("Valitse haluamasi vaikeustaso")) {
			MiekkaseikkailuV2.setVaikeustaso(4);
			tulosta("\n\nHaluat siis MAHDOTTOMAN pelin? Oletko hullu?");
			System.out.println("Vaikestaso on: " + MiekkaseikkailuV2.getVaikeustaso());
			}
			}
		});
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Malgun Gothic Semilight", Font.PLAIN, 16));
		button.setBackground(new Color(0, 128, 128));
		button.setBounds(450, 789, 634, 47);
		button.setVisible(false);
		contentPane.add(button);
		
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			if (textPane_1.getText().equals("Valitse haluamasi vaikeustaso")) {
			if (MiekkaseikkailuV2.getVaikeustaso() == 1 || MiekkaseikkailuV2.getVaikeustaso() == 2 || MiekkaseikkailuV2.getVaikeustaso() == 3 || MiekkaseikkailuV2.getVaikeustaso() == 4) {
			btnNewButton.setText("Vaihtoehto 1");
			btnNewButton_1.setText("Vaihtoehto 2");
			btnNewButton_2.setText("Vaihtoehto 3");
			button.setText("Vaihtoehto 4");
			btnNewButton_3.setVisible(false);
			MiekkaseikkailuV2.taso1();
			} else {
			tulosta("\n\nOle hyv� ja valitse haluamasi vaikeustaso.");
			}
			}
			else if (Hahmo.getLuokka().equals("Ritari") || Hahmo.getLuokka().equals("Taikuri") || Hahmo.getLuokka().equals("Jousimies")) {
			MiekkaseikkailuV2.vaikeus();
			btnNewButton.setText("Helppo");
			btnNewButton_1.setText("Keskivaikea");
			btnNewButton_2.setText("Vaikea");
			button.setVisible(true);
			} else {
			tulosta("\n\nOle hyv� ja valitse haluamasi luokka.");
			}
			}
		});
		btnNewButton_3.setBounds(499, 882, 513, 42);
		contentPane.add(btnNewButton_3);
		
		JLabel lblNewLabel_4 = new JLabel("Version 2.0");
		lblNewLabel_4.setFont(new Font("Lithos Pro Regular", Font.PLAIN, 15));
		lblNewLabel_4.setForeground(Color.WHITE);
		lblNewLabel_4.setBounds(1455, 907, 116, 31);
		contentPane.add(lblNewLabel_4);
		
		
		lblNewLabel.setBackground(new Color(0, 0, 0));
		lblNewLabel.setIcon(new ImageIcon("kuvat/miekkaseikkailu.png"));
		lblNewLabel.setBounds(281, -404, 1212, 1080);
		contentPane.add(lblNewLabel);
		
		
		lblNewLabel_1.setIcon(new ImageIcon("kuvat/miekkaseikkailulayout.jpg"));
		lblNewLabel_1.setBounds(-15, 0, 1920, 1080);
		lblNewLabel_1.setVisible(false);
		contentPane.add(lblNewLabel_1);
				
		lblNewLabel_3.setIcon(new ImageIcon("kuvat/miekkaseikkailulayout2.jpg"));
		lblNewLabel_3.setBounds(-353, 0, 3180, 1357);
		lblNewLabel_3.setVisible(false);
		contentPane.add(lblNewLabel_3);
		
			
		lblNewLabel_2.setIcon(new ImageIcon("kuvat/miekkaseikkailulayout3.png"));
		lblNewLabel_2.setBounds(-111, -385, 1919, 1731);
		lblNewLabel_2.setVisible(false);
		contentPane.add(lblNewLabel_2);

	}
	
	
	/**
	 * Tulostaa tekstin textArea osaan m��ritell��n usein MiekkaseikkailuV2.javassa.
	 * @param teksti teksti on kirjoitettu k�sin Miekkaseikkailu.javassa
	 */
	public static void tulosta(String teksti) {
	textArea.append(teksti);
	}
	
	/**
	 * Asettaa <code>String teksti</code>n otsikon tekstiksi.
	 * @param teksti teksti on kirjoitettu k�sin Miekkaseikkailu.javassa
	 */
	public static void otsikko(String teksti) {
	textPane.setText(teksti);
	}
	
	/**
	 * Asettaa <code>String teksti</code>n tekstiksi Esim. Taso 1, Taso 2, Valitse haluamasi luokka.
	 * @param teksti teksti on kirjoitettu k�sin Miekkaseikkailu.javassa
	 */
	public static void teksti�(String teksti) {
	textPane_1.setText(teksti);
	}
	
	/**
	 * Asettaa <code>String teksti</code>n painikkeen tekstiksi.
	 * @param teksti teksti on kirjoitettu k�sin Miekkaseikkailu.javassa
	 */
	public static void painike1(String teksti) {
	btnNewButton.setText(teksti);	
	}
	
	/**
	 * Asettaa <code>String teksti</code>n painikkeen tekstiksi.
	 * @param teksti teksti on kirjoitettu k�sin Miekkaseikkailu.javassa
	 */
	public static void painike2(String teksti) {
	btnNewButton_1.setText(teksti);	
	}
	
	/**
	 * Asettaa <code>String teksti</code>n painikkeen tekstiksi.
	 * @param teksti teksti on kirjoitettu k�sin Miekkaseikkailu.javassa
	 */
	public static void painike3(String teksti) {
	btnNewButton_2.setText(teksti);	
	}
	
	/**
	 * Asettaa <code>String teksti</code>n painikkeen tekstiksi.
	 * @param teksti teksti on kirjoitettu k�sin Miekkaseikkailu.javassa
	 */
	public static void painike4(String teksti) {
	button.setText(teksti);	
	}
	
	/**
	 * Piilottaa nelos nappulan
	 */
	public static void piilotapainike4() {
	button.setVisible(false);
	}
	
	/**
	 * Tekee nelos nappulasta n�kyv�n
	 */
	public static void n�yt�painike4() {
	button.setVisible(true);
	}

	/**
	 * Piilottaa kolmos nappulan
	 */
	public static void piilotapainike3() {
	btnNewButton_2.setVisible(false);		
	}
	
	/**
	 * Tekee kolmos nappulasta n�kyv�n
	 */
	public static void n�yt�painike3() {
	btnNewButton_2.setVisible(true);		
	}
	
	/**
	 * Aloittaa uuden pelin m��ritt�� painikkeet "mitk� olivat pelin alussa" tilaan. <br>
	 * Asettaa kullan nollaksi.
	 */
	public static void uusipeli() {
		
		Hahmo hahmo = new Hahmo();
		System.out.println(hahmo);
		
		Hahmo.setKulta(0);
		
		painike1("Ritari - 200 HP");
		painike2("Taikuri - 100 HP");
		painike3("Jousimies - 150 HP");
		painike4("Mahdoton");
		
		n�yt�painike3();
		btnNewButton_3.setVisible(true);

		GUI.tulosta("\n\nValitse painikkeista haluamasi hahmoluokka ja paina hyv�ksy nappia.");			
		
	}
	
	
}
