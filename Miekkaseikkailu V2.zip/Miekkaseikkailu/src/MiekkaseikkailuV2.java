
/** Hahmo luokan kuvaus<br><br>
 * Hahmoluokassa m��ritell��n hahmoa koskevia asioita esim. (hahmon nimi, hp, kulta, luokka)<br>
 * @author Ville P�ll�nen
 * @author Robert Hakola
 */
class Hahmo {

	/** String nimi<br><br>
	 * Hahmon nimi jota k�ytet��n oliossa m��rittelem��n hahmon nimi<br>
	 */
	private static String nimi;
	/** String luokka<br><br>
	 * M��ritt�� hahmon luokan, jota k�ytet��n my�s valintojen muuttamiseen luokka kohtaisesti<br>
	 */
	private static String luokka;
	/** String kulta<br><br>
	 * Hahmon ker��m� kultam��r� pelin aikana.<br>
	 * Jos peli alkaa alusta kulta nollaantuu.
	 */
	private static int kulta;
	
	
	/** Hahmoluokan parametriton konstruktori<br><br>
	 * Konstruktorissa m��ritell��n nimi nimett�m�ksi ja luokka luokattomaksi.<br>
	 */
	public Hahmo() {
	nimi = "Nimet�n";
	luokka = "Luokaton";
	}
	/** Hahmoluokan parametrillinen konsruktori<br><br>
	 * Konstruktoria k�ytet��n nimen asettamiseen hahmolle.<br>
	 * @param nimi on hahmolle kirjoitettu nimi
	 */
	public Hahmo(String nimi) {
	Hahmo.nimi = nimi;
	}
	/** String ritari metodi<br><br>
	 * M��rittelee luokan ritariksi ja Hahmon HP:t 200<br>
	 * @return luokan arvon.
	 */
	static String ritari() {
		luokka = "Ritari";
		MiekkaseikkailuV2.HP = 200;
		return luokka;
	}
	/** String taikuri metodi<br><br>
	 * M��rittelee luokan taikuriksi ja Hahmon HP:t 100<br>
	 * @return luokan arvon.
	 */
	static String taikuri() {
		luokka = "Taikuri";
		MiekkaseikkailuV2.HP = 100;
		return luokka;
	}
	/** String jousimies metodi<br><br>
	 * M��rittelee luokan ritariksi ja Hahmon HP:t 150<br>
	 * @return luokan arvon.
	 */
	static String jousimies() {
		luokka = "Jousimies";
		MiekkaseikkailuV2.HP = 150;
		return luokka;
	}
	
	/** Luokan Getteri<br><br>
	 * Tarvittaessa hakee luokan ja palauttaa sen arvon<br>
	 * @return luokan arvon.
	 */
	public static String getLuokka() {
		return luokka;
	}
	/** Luokan Setteri<br><br>
	 * M��ritt�� luokan nimen<br>
	 * @param luokka luokka on hahmo luokka.
	 */
	public static void setLuokka(String luokka) {
		Hahmo.luokka = luokka;
	}
	/** String ritari metodi<br><br>
	 * HP laskuri joka laskee HP arvon tasojen v�lill�<br>
	 * Jos HP on nolla tai pienempi HP m��ritet��n nollaksi ja kulta nollataan<br>
	 * pelin�yt�lle tulostetaan teksti voi ei taisit kuolla...<br>
	 * jonka j�lkeen kutsutaan MiekkaseikkailuV2 luokan lopetus() metodia.
	 * @return HP arvon.
	 * @param HP muuttuja, joka muuttuu peli valintojen mukaan.
	 */
	static int laskuri(int HP) {
		System.out.println("\nHP:ta j�ljell�: " + HP);
		if (HP <= 0) {
			HP = 0;
			setKulta(0);
			GUI.tulosta("\n\nVoi ei! Taisit kuolla! El�m�si ei riitt�nyt loppuun saakka, joten H�visit pelin!");
			MiekkaseikkailuV2.lopetus();
		}
		return HP;
	}
	/** toString metodi<br><br>
	 * M��rittelee miten hahmo tulostetaan<br>
	 * @return nimen ja luokan sen hetkiset arvot.
	 */
	public String toString() {
	return nimi + "\n" + luokka + "\n" + MiekkaseikkailuV2.HP;
	}
	/** Kulta Getteri<br><br>
	 * Hakee kullan sen hetkisen arvon<br>
	 * @return kullan arvon.
	 */
	public static int getKulta() {
		return kulta;
	}
	/** Kulta Setteri<br><br>
	 * Asettaa kullan kulta muuttujan mukaan<br>
	 * @param kulta muuttuja joka muuttuu pelin eri vaiheissa.
	 */
	public static void setKulta(int kulta) {
		Hahmo.kulta = kulta;
	}
	/** Nimi Getteri<br><br>
	 * Hakee nimen t�m�n hetkisen arvon<br>
	 * @return nimen arvon
	 */
	public static String getNimi() {
		return nimi;
	}
	/** Nimi Setteri<br><br>
	 * Asettaa nimen<br>
	 * @param nimi asettaa nimen nimeksi
	 */
	public static void setNimi(String nimi) {
		Hahmo.nimi = nimi;
	}

}


/** RandomEvent luokka<br><br>
 * Luokassa m��rittell��n kolmen eri eventin vaihtoehdot.<br>
 * @see #Monsterim�tt�(int random)
 * @see #Vankilapako(int random)
 * @see #Lampunhenki(int random)
 * @see MiekkaseikkailuV2#arvo()
 * @see MiekkaseikkailuV2#peli()
 */
class RandomEvent {
	/** Monsterim�tt� metodi<br><br>
	 * Monsterim�tt� arpoo mosterin ja sen aiheuttaman vahingon<br>
	 * <code>int monsteri</code> m��rittelee mik� monsteri arvotaan<br>
	 * <code>int tuplat</code> m��rittelee tuleeko monsteri uudestaan<br>
	 * <code>int vahinko</code> arpoo kuinka paljon vahinkoa pelaaja ottaa<br>
	 * @param random tulostetaan jos Monsterim�tt�� kutsutaan
	 */
	static void Monsterim�tt�(int random) {
	System.out.println(random);
	GUI.tulosta("\n\nMonsterim�tt�");
	
	int monsteri = (int) (Math.random() * 3 + 1); 
	int tuplat = (int) (Math.random() * 100 + 1);
	int vahinko = (int) (Math.random() * 50 + 1);
	
	if (monsteri == 1) {
	GUI.tulosta("\n\nKohtaat mennink�isen");
	
	if (Hahmo.getLuokka().equals("Taikuri")) {
	GUI.tulosta("\n\nKoska olet taikuri, jolle mennink�inen on heikko et ota t�st� monsterista vahinkoa");	
	} else {
		GUI.tulosta("\n\nMonsteri tekee sinuun " + vahinko + " verran vahinkoa");
		MiekkaseikkailuV2.HP -= vahinko;
		Hahmo.laskuri(MiekkaseikkailuV2.HP);
	}
	if (tuplat > 0 && tuplat < 6) {
	GUI.tulosta("\n\nKohtaat mennink�isen uudestaan");	
	if (Hahmo.getLuokka().equals("Taikuri")) {
		GUI.tulosta("\n\nKoska olet taikuri, jolle mennink�inen on heikko et ota t�st� monsterista vahinkoa");	
	} else {
		GUI.tulosta("\n\nMennink�inen tekee sinuun " + vahinko + " verran vahinkoa");
		MiekkaseikkailuV2.HP -= vahinko;
		Hahmo.laskuri(MiekkaseikkailuV2.HP);
	}
	}
	
	}
	
	if (monsteri == 2) {
	GUI.tulosta("\n\nKohtaat hullun ritarin");
	if (Hahmo.getLuokka().equals("Ritari")) {
		GUI.tulosta("\n\nKoska olet ritari, jolle hullu ritari on heikko et ota t�st� monsterista vahinkoa");	
		}
	if (Hahmo.getLuokka().equals("Jousimies")) {
		GUI.tulosta("\n\nKoska olet jousimies, jolle hullu ritari on heikko et ota t�st� monsterista vahinkoa");	
		}
	else {
		GUI.tulosta("\n\nHullu ritari tekee sinuun " + vahinko + " verran vahinkoa");
		MiekkaseikkailuV2.HP -= vahinko;
		Hahmo.laskuri(MiekkaseikkailuV2.HP);
	}
	if (tuplat > 0 && tuplat < 6) {
	GUI.tulosta("\n\nKohtaat hullun ritarin uudestaan");
	System.out.println(tuplat);
	if (Hahmo.getLuokka().equals("Ritari")) {
		GUI.tulosta("\n\nKoska olet ritari, jolle hullu ritari on heikko et ota t�st� monsterista vahinkoa");	
		}
	if (Hahmo.getLuokka().equals("Jousimies")) {
		GUI.tulosta("\n\nKoska olet jousimies, jolle hullu ritari on heikko et ota t�st� monsterista vahinkoa");	
		}
	else {
		GUI.tulosta("\n\nHullu ritari tekee sinuun " + vahinko + " verran vahinkoa");
		MiekkaseikkailuV2.HP -= vahinko;
		Hahmo.laskuri(MiekkaseikkailuV2.HP);
	}
	}	
	
	}
	
	if (monsteri == 3) {
	GUI.tulosta("\n\nKohtaat p��tt�m�n ratsuttoman ratsumiehen");
	
	if (Hahmo.getLuokka().equals("Taikuri")) {
	GUI.tulosta("\n\nKoska olet taikuri, jolle p��t�n ratsuton ratsumies on heikko et ota t�st� monsterista vahinkoa");	
	} else {
		GUI.tulosta("\n\nP��t�n ratsuton ratsumies tekee sinuun " + vahinko + " verran vahinkoa");
		MiekkaseikkailuV2.HP -= vahinko;
		Hahmo.laskuri(MiekkaseikkailuV2.HP);
	}
	if (tuplat > 0 && tuplat < 6) {
	GUI.tulosta("\n\nKohtaat p��tt�m�n ratsumiehen uudestaan");	
	if (Hahmo.getLuokka().equals("Taikuri")) {
		GUI.tulosta("\n\nKoska olet taikuri, jolle p��t�n ratsuton ratsumies on heikko et ota t�st� monsterista vahinkoa");	
	} else {
		GUI.tulosta("\n\nP��t�n ratsuton ratsumies tekee sinuun " + vahinko + " verran vahinkoa");
		MiekkaseikkailuV2.HP -= vahinko;
		Hahmo.laskuri(MiekkaseikkailuV2.HP);
	}
	}
	
	}
	}
	
	/** Vankilapako metodi<br><br>
	 * M��ritt�� vankilapako minipelin<br>
	 * <code>int random2</code> m��rittelee mik� vaihtoehtoista arvotaan, jos pelaajalle ei ole 10 000 rahaa<br>
	 * jos <code>int random 2</code> on 1-20 v�lilt� pelaaja kuolee <br>
	 * jos <code>int random 2</code> on 21-80 v�lilt� pelaaja pelaaja ottaa <code>int vahinko2</code> arpoman vahingon. <br>
	 * jos <code>int random 2</code> on 81-100 v�lilt� pelaaja p��see pakoon vankilasta ilman seuraamuksia.
	 * @see Hahmo#getKulta()
	 * @param random random n�ytt�� luvun jos vankilapakoa kutsutaan.
	 */
	static void Vankilapako(int random) {
	System.out.println(random);
	GUI.tulosta("\n\nVankilapako");
	
	GUI.tulosta("\n\nOlet lain mielest� lain v��r�ll� puolella ja joudut vankilaan");
	
	int random2 = (int)(Math.random() * 100 + 1);
	
	if (Hahmo.getKulta() >= 10000) {
		GUI.tulosta("\n\nMaksoit vartialle 10 000 rahaa ja p��sit vapaaksi.");
		Hahmo.setKulta(Hahmo.getKulta() - 10000);
		} else {
		GUI.tulosta("\n\nSinulla ei ole tarpeeksi kultaa lahjomaan vartiaa.");
		GUI.tulosta("\nKoska sinulla ei ole rahea sinun ainoa vaihtoehtosi on paeta vankilasta.");
		
		GUI.tulosta("\n\nYritit pakoa, ja ");
		
		if (random2 > 0 && random2 < 21) {
		System.out.println(random2);
		GUI.tulosta("kuolit");
		MiekkaseikkailuV2.HP = 0;
		Hahmo.laskuri(MiekkaseikkailuV2.HP);
		}
		
		if (random2 > 20 && random2 < 81) {
		System.out.println(random2);
		int vahinko2 = (int) (Math.random() * 50 + 1);
		GUI.tulosta("p��sit pakoon, mutta otit vahinkoa: " + vahinko2);
		MiekkaseikkailuV2.HP -= vahinko2;
		Hahmo.laskuri(MiekkaseikkailuV2.HP);
		}
		
		if (random2 > 80 && random2 < 101) {
		System.out.println(random2);
		GUI.tulosta("p��sit pakoon");
	
		}
		}
	
	}
	/** Lampunhenki metodi<br><br>
	 * M��ritt�� Lampunhenki minipelin<br>
	 * <code>int random2</code> m��rittelee saako pelaaja rahaa vai HP:ta<br>
	 * jos <code>int random 2</code> on 1-50 pelaaja saa HP:ta <code>int lis��El�m��</code> verran. <br>
	 * jos <code>int random 2</code> on 51-100 pelaaja saa rahaa  <code>int lis��Rahaa </code> verran <br>
	 * @see Hahmo#getKulta()
	 * @see Hahmo#laskuri(int)
	 * @param random random on luku joka n�ytet��n jos peli� on kutsuttu.
	 */
	static void Lampunhenki(int random) {
		
	GUI.tulosta("\n\nLampunhenki");	
	System.out.println(random);
	
	int random2 = (int)(Math.random() * 100 + 1);
	
	GUI.tulosta("\n\nHenki ilmestyy h�n tarjoaa HP:ta tai rahaa");
	
	int lis��El�m�� = (int) (Math.random() * 30 + 1);
	int lis��Rahaa = (int) (Math.random() * 100000 + 1);
	
	if (random2 > 0 && random2 < 51) {
	GUI.tulosta("\n\nHenki toteuttaa toiveesi ja saat HP:n�: " + lis��El�m��);
	MiekkaseikkailuV2.HP += lis��El�m��;
	}
	
	if (random2 > 50 && random2 < 101) {
	GUI.tulosta("\n\nHenki toteuttaa toiveesi ja saat rahana: " + lis��Rahaa);
	Hahmo.setKulta(Hahmo.getKulta() + lis��Rahaa);
	}

}
}


/** Ohjelman kuvaus:<br><br>
 * T�m� peli on keskiaikainen tekstiseikkailupeli.<br>
 * Peliss� pelaaja valitsee mielest��n sopivimman vaihtoehdon, kun h�nelt� kysyt��n sit�.<br>
 * Pelaaja voi valita valintansa painikkeiden avulla.<br>
 * Peliss� on 10 tasoa, jonka aikana pelaaja h�vi�� tai voittaa pelin.<br>
 * Peliss� on my�s satunnaisia tapahtumia.<br>
 * H�vitess��n tai voittaessaan pelin pelaajalla on mahdollisuus aloittaa peli alusta tai lopettaa se.
 * @author Ville P�ll�nen
 * @author Robert Hakola
 */
public class MiekkaseikkailuV2 {
	
		/** HP:n kuvaus: <br><br>
		 * HP on <code>int</code> tyyppinen HP-muuttuja, jota k�ytet��n {@link Hahmo#laskuri}-metodin lis�ksi, my�s kaikissa taso-metodeissa ja tasovalinnoissa, sek� RandomEvent luokassa.<br>
		 * @see Hahmo#laskuri
		 * @see #taso1
		 * @see #taso2
		 * @see #taso3
		 * @see #taso4
		 * @see #taso5
		 * @see #taso6
		 * @see #taso7
		 * @see #taso8
		 * @see #taso9
		 * @see #taso10
		 * @see #taso1valinta1       
		 */
		static int HP;
		/** Vaikeustason kuvaus: <br><br>
		 * Vaikeustaso on <code>int</code> tyyppinen muuttuja ja se m��ritet��n painikkeen avulla.
		 * @see #vaikeus
		 * @see #getVaikeustaso
		 */
		private static int vaikeustaso;

		
		
		/** P��ohjelman kuvaus:<br><br>
		 * P��ohjelmassa luodaan uusi hahmo olio ja kysyt��n my�s pelaajan nime� ja h�nen valitsemaa luokkaa.
		 * Uutta tasoa ei aloiteta, jos {@link #HP}-muuttujan arvo on v�hemm�n tai yht� suuri kuin 0.<br>
		 * Jos pelaaja h�vi�� pelin h�nelt� kysyt��n haluaako h�n jatkaa pelaamista. <br>
		 * Jos pelaaja p��tt�� yritt�� uudestaan h�n aloittaa pelin alusta.<br>
		 * @param args P��metodin oletusarvo.
		 * @see #lopetus
		 * @see Hahmo#laskuri
		 * @see GUI#tulosta
		 * @see GUI#otsikko
		 * @see GUI#teksti�
		 */
		public static void main(String args[]){
			
		
			GUI.otsikko("Kirjoita haluamasi nimi: ");
			
				
			Hahmo hahmo = new Hahmo();
			System.out.println(hahmo);
				
			GUI.teksti�("Valitse haluamasi luokka");
			GUI.tulosta("Valitse painikkeista haluamasi hahmoluokka ja paina hyv�ksy nappia.");
					
			
	}
		
		/** Vaikeus metodin kuvaus:<br><br>
		 * M��rittelee GUI.javaan tietyn tekstiotsikon. <br>
		 * Tekstiotsikko m��r�� n�pp�inten toiminnot.
		 * @see #vaikeustaso
		 * @see GUI#teksti�
		 */
	 static void vaikeus() {	
			
			GUI.teksti�("Valitse haluamasi vaikeustaso");
			
	 }
		
		/** Taso1 metodin kuvaus:<br><br> 
		 * Taso1 metodi muuttaa tekstin Taso 1:ksi ja tulostaa taso1 kuvauksen, jonka j�lkeen uudelleen nime�� painikkeet.<br>
		 * Jos pelaaja on Ritari h�nelle tulostetaan uniikki teksti ja painikkeet. <br>
		 * Jos pelaaja on Taikuri h�nelle tulostetaan uniikki teksti ja painikkeet. <br>
		 * Jos pelaaja on Jousimies h�nelle tulotetaan uniikki teksti ja painikkeet. <br>
		 * Seuraavalle tasolle voidaan jatkaa valitsemalla tasovalinta painikkeiden avulla. 	
		 * @see GUI#teksti�
		 * @see GUI#tulosta
		 * @see GUI#painike1
		 * @see GUI#painike2
		 * @see GUI#painike3
		 * @see GUI#piilotapainike4
		 * @see #taso1valinta1
		 * @see #taso1valinta2
		 * @see #taso1valinta3
		 */
		static void taso1() {
			
			GUI.teksti�("Taso 1");
			GUI.piilotapainike4();
		
			
			if (Hahmo.getLuokka().equals("Ritari")) {
			GUI.tulosta("\n\nAvaat silm�si ja her��t pime�st� mets�st�...\nKatselet itse�si vahinkojen varalta ja huomaat olevasi ritari, jolla ei ole miekkaa eik� kilpe�...\nOlisi hauska tiet�� miten t�nne p��dyit, ajattelet...\nN�ytt�� silt�, ett� olet l�ynyt p��si johonkin, ehk� kannattaisi n�ytt�� p��t�si l��k�rille...\nOlet my�s menett�nyt muistisi....\nEtk� edes tied� tarkalleen miss� olet...\nSelviyty�ksesi tarvitset aseen tai kilven\nMit� teet?");
			GUI.painike1("L�hde etsim��n miekkaa etel�st�");
			GUI.painike2("L�hde etsim��n miekkaa ja kilpe� pohjoisesta");
			GUI.painike3("L�hde etsim��n kilpe� id�st�");
			}
			if (Hahmo.getLuokka().equals("Taikuri")) {
			GUI.tulosta("\n\nAvaat silm�si ja her��t pime�st� mets�st�...\nKatselet itse�si vahinkojen varalta ja huomaat olevasi Taikuri, jolla ei ole taikasauvaa tai taikakirjaa...\nOlisi hauska tiet�� miten t�nne p��dyit, ajattelet...\nN�ytt�� silt�, ett� olet l�ynyt p��si johonkin, ehk� kannattaisi n�ytt�� p��t�si l��k�rille...\nOlet my�s menett�nyt muistisi....\nEtk� edes tied� tarkalleen miss� olet...\nSelviyty�ksesi tarvitset taikasauvan tai taikakirjan\nMit� teet?");
			GUI.painike1("L�hde etsim��n taikasauvaa etel�st�");
			GUI.painike2("L�hde etsim��n taikasauvaa ja taikakirjaa pohjoisesta");
			GUI.painike3("L�hde etsim��n taikakirjaa id�st�");
			}
			if (Hahmo.getLuokka().equals("Jousimies")) {
			GUI.tulosta("\n\nAvaat silm�si ja her��t pime�st� mets�st�...\nKatselet itse�si vahinkojen varalta ja huomaat olevasi Jousimiest�, jolla ei ole jousta tai nuolia...\nOlisi hauska tiet�� miten t�nne p��dyit, ajattelet...\nN�ytt�� silt�, ett� olet l�ynyt p��si johonkin, ehk� kannattaisi n�ytt�� p��t�si l��k�rille...\nOlet my�s menett�nyt muistisi....\nEtk� edes tied� tarkalleen miss� olet...\nSelviyty�ksesi tarvitset jousen tai nuolia\nMit� teet?");
			GUI.painike1("L�hde etsim��n jousta etel�st�");
			GUI.painike2("L�hde etsim��n jousta ja nuolia pohjoisesta");
			GUI.painike3("L�hde etsim��n nuolia id�st�");
			}
			
		}
		
	  
		/** Taso2 metodin kuvaus:<br><br>
		 * Jos pelaajan {@link #HP} on suurempi kuin 0 <code>if</code>-lauseen sis�ll� olevat asiat suoritetaan. <br>
		 * Taso2 metodi muuttaa tekstin Taso 2:ksi ja tulostaa taso2 kuvauksen, jonka j�lkeen uudelleen nime�� painikkeet.<br>
		 * Seuraavalle tasolle voidaan jatkaa valitsemalla tasovalinta painikkeiden avulla.
		 * @see GUI#teksti�
		 * @see GUI#tulosta
		 * @see GUI#painike1
		 * @see GUI#painike2
		 * @see GUI#painike3
		 * @see #taso2valinta1
		 * @see #taso2valinta2
		 * @see #taso2valinta3
		 */
		static void taso2() {
			
			if (HP > 0) {
			
			GUI.teksti�("Taso 2");
			
			GUI.tulosta("\n\nL�hdit jatkamaan matkaa eteenp�in...\nP��dyt entist� synkemp��n osioon mets�ss�...\nLopulta p��dyt polun risteykseen...\nKuulet hyyt�v�n karjaisun takaasi...\nMit� teet?");
			
			GUI.painike1("Run! Forest! Run!");
			GUI.painike2("Et pelk��! L�hdet rauhallisesti juoksemaan");
			GUI.painike3("J��t ihailemaan maisemia");
			}
			
}
		/** Taso3 metodin kuvaus:<br><br>
		 * Jos pelaajan {@link #HP} on suurempi kuin 0 <code>if</code>-lauseen sis�ll� olevat asiat suoritetaan. <br>
		 * Taso3 metodi muuttaa tekstin Taso 3:ksi ja uudelleen nime�� painikkeet, jonka j�lkeen tulostaa taso4 kuvauksen. <br>
		 * Seuraavalle tasolle voidaan jatkaa valitsemalla tasovalinta painikkeiden avulla.
		 * @see GUI#teksti�
		 * @see GUI#tulosta
		 * @see GUI#painike1
		 * @see GUI#painike2
		 * @see GUI#painike3
		 * @see #taso3valinta1
		 * @see #taso3valinta2
		 * @see #taso3valinta3
		 */
		 static void taso3() {
			
			if (HP > 0) {
			
			GUI.teksti�("Taso 3"); 
			
			GUI.painike1("Etsi purosta purtavaa :)");
			GUI.painike2("T�yt� juomapullo vedell�");
			GUI.painike3("Ohita puro");
		
			GUI.tulosta("\n\nP��sty�si jotenkin ihmeen kaupalla karkuun hirvi�t� matkasi jatkuu...\nJ�it kuitenkin miettim��n viel�k� kohtaat t�m�n hirvitt�v�n otuksen...\nJatkoit matkaasi ja kohtaat puron...\nMit� teet?");
			}
	
}
		/** Taso4 metodin kuvaus:<br><br>
			 * Jos pelaajan {@link #HP} on suurempi kuin 0 <code>if</code>-lauseen sis�ll� olevat asiat suoritetaan. <br>
			 * Taso4 metodi muuttaa tekstin Taso 4:ksi ja uudelleen nime�� painikkeet, jonka j�lkeen tulostaa taso4 kuvauksen. <br>
			 * Seuraavalle tasolle voidaan jatkaa valitsemalla tasovalinta painikkeiden avulla.
			 * @see GUI#teksti�
			 * @see GUI#tulosta
			 * @see GUI#painike1
			 * @see GUI#painike2
			 * @see GUI#painike3
			 * @see #taso4valinta1
			 * @see #taso4valinta2
			 * @see #taso4valinta3
			 */
		 static void taso4() {
			
			if (HP > 0) {
			
			GUI.teksti�("Taso 4"); 

			GUI.painike1("Taistele Mustaa Ritaria vastaan");
			GUI.painike2("L�hde karkuun!");
			GUI.painike3("Juttele Mustan Ritarin kanssa");
			
			GUI.tulosta("\n\nJatkat matkaa...\nYht�kki� polun reunalta eteesi hypp�si uhkaavan n�k�inen Musta Ritari...\nValitse viisaasti...");
			}
			
			
}
			/** Taso5 metodin kuvaus:<br><br>
			 * Jos pelaajan {@link #HP} on suurempi kuin 0 <code>if</code>-lauseen sis�ll� olevat asiat suoritetaan. <br>
			 * Taso5 metodi muuttaa tekstin Taso 5:ksi ja uudelleen nime�� painikkeet, jonka j�lkeen tulostaa taso5 kuvauksen. <br>
			 * Seuraavalle tasolle voidaan jatkaa valitsemalla tasovalinta painikkeiden avulla.
			 * @see GUI#teksti�
			 * @see GUI#tulosta
			 * @see GUI#painike1
			 * @see GUI#painike2
			 * @see GUI#painike3
			 * @see GUI#painike4
			 * @see GUI#n�yt�painike4
			  * @see #taso5valinta1
			 * @see #taso5valinta2
			 * @see #taso5valinta3
			 * @see #taso5valinta4
			 */
		 static void taso5() {
			
			if (HP > 0) {
			
			GUI.teksti�("Taso 5");  
			
			GUI.painike1("J�� lep��m��n lepopaikkaan");
			GUI.painike2("Tutki leiripaikkaa nopeasti");
			GUI.painike3("Tutki leiripaikkaa tarkasti");
			GUI.painike4("Jatka matkaasi");
			GUI.n�yt�painike4();
			GUI.tulosta("\n\nLy�ty�si ritarin oli aika huilata ja p��dyit v�h�n matkan p��h�n...\nSielt� l�yd�t Mustan Ritarin lepopaikan...\nValintanasi ovat seuraavat...");
			}
		
}
			/** Taso6 metodin kuvaus:<br><br>
			 * Jos pelaajan {@link #HP} on suurempi kuin 0 <code>if</code>-lauseen sis�ll� olevat asiat suoritetaan. <br>
			 * Taso6 metodi muuttaa tekstin Taso 6:ksi ja uudelleen nime�� painikkeet, jonka j�lkeen tulostaa taso6 kuvauksen. <br>
			 * Seuraavalle tasolle voidaan jatkaa valitsemalla tasovalinta painikkeiden avulla.
			 * @see GUI#teksti�
			 * @see GUI#tulosta
			 * @see GUI#painike1
			 * @see GUI#painike2
			 * @see GUI#painike3
			 * @see GUI#painike4
			 * @see #taso6valinta1
			 * @see #taso6valinta2
			 * @see #taso6valinta3
			 * @see #taso6valinta4
			 */
		 static void taso6() {
			
			if (HP > 0) {
			
			GUI.teksti�("Taso 6"); 
			
			GUI.painike1("L�hde hiipim��n huudon suuntaan");
			GUI.painike2("L�hde k�velem��n huudon suuntaan");
			GUI.painike3("L�hde juoksemaan huudon suuntaan");
			GUI.painike4("L�hde ry�mim��n huudon suuntaan");
			
			GUI.tulosta("\n\nHer�sit meteliin joku huusi Edwardia, p��ttelit ett� kyseess� oli ritari, jonka olit aikaisemmin tappanut.\nOnneksi olin mennyt nukkumaan kauemmaksi ritarin lepopaikasta, n�in tuumasit itseksesi.\nMit� teet?");
			}
			

}
			/** Taso7 metodin kuvaus:<br><br>
			 * Jos pelaajan {@link #HP} on suurempi kuin 0 <code>if</code>-lauseen sis�ll� olevat asiat suoritetaan. <br>
			 * Taso7 metodi muuttaa tekstin Taso 7:ksi ja uudelleen nime�� painikkeet, jonka j�lkeen tulostaa taso7 kuvauksen. <br>
			 * Seuraavalle tasolle voidaan jatkaa valitsemalla tasovalinta painikkeiden avulla.
			 * @see GUI#teksti�
			 * @see GUI#tulosta
			 * @see GUI#painike1
			 * @see GUI#painike2
			 * @see GUI#painike3
			 * @see GUI#piilotapainike4
			 * @see #taso7valinta1
			 * @see #taso7valinta2
			 * @see #taso7valinta3
			 */
		 static void taso7() {
			
			if (HP > 0) {
		
			GUI.teksti�("Taso 7"); 
			
			GUI.piilotapainike4();
			
			GUI.painike1("L�hde v�litt�m�sti seuraamaan Valkoista Ritaria");
			GUI.painike2("Odota, ett� Valkoinen Ritari poistuu luolasta");
			GUI.painike3("L�hde jatkamaan matkaasi poisp�in luolasta");
		
			GUI.tulosta("\n\nOnnistuit v�ltt�m��n Valkoisen Ritarin murhaavan katseen...\nSeurasit h�nt� onnistuneesti...\nHuomaat, ett� h�n on menossa luolaan...\nOlikohan t�m� h�nen ja Mustan Ritarin aarrek�tk�, tuumasit...\nMit� teet?");
			}
			
}
			/** Taso8 metodin kuvaus:<br><br>
			 * Jos pelaajan {@link #HP} on suurempi kuin 0 <code>if</code>-lauseen sis�ll� olevat asiat suoritetaan. <br>
			 * Jos pelaaja on Taikuri pelivalintanapit ja tekstit muutetaan h�nelle sopiviksi. <br>
			 * Taso8 metodi muuttaa tekstin Taso 8:ksi ja uudelleen nime�� painikkeet, jonka j�lkeen tulostaa taso8 kuvauksen. <br>
			 * Seuraavalle tasolle voidaan jatkaa valitsemalla tasovalinta painikkeiden avulla.
			 * @see GUI#teksti�
			 * @see GUI#tulosta
			 * @see GUI#painike1
			 * @see GUI#painike2
			 * @see GUI#painike3
			 * @see GUI#n�yt�painike4
			 * @see #taso8valinta1
			 * @see #taso8valinta2
			 * @see #taso8valinta3
			 * @see #taso8valinta4
			 */
		static void taso8() {
			
			if (HP > 0) {
		
			GUI.teksti�("Taso 8"); 
			
			if (Hahmo.getLuokka().equals("Taikuri")) {
				GUI.painike1("Potkaise haltia rotkoon");
				GUI.painike2("Anna aarre haltialle");
				GUI.painike3("Ohita rotko");
				GUI.painike4("Heit� aarre rotkoon");
				GUI.n�yt�painike4();
				
			GUI.tulosta("\n\nLy�ty�si aiemman kohtaamasi hirvi�n luolassa...\nL�yd�t sielt� aarteen, onneksi olkoon...!\nL�yd�t tiesi ulos luolasta...\nP��t�t l�hte� jatkamaan polkua eteenp�in...\nN�et edess�si rotkon ja haltian...\nMit� teet?");	
			} else {
			GUI.painike1("Potkaise huppup�inen henkil� rotkoon");
			GUI.painike2("Anna aarre huppup�iselle henkil�lle");
			GUI.painike3("Ohita rotko");
			GUI.painike4("Heit� aarre rotkoon");
			GUI.n�yt�painike4();
			
			GUI.tulosta("\n\nLy�ty�si aiemman kohtaamasi hirvi�n luolassa...\nL�yd�t sielt� aarteen, onneksi olkoon...!\nL�yd�t tiesi ulos luolasta...\nP��t�t l�hte� jatkamaan polkua eteenp�in...\nN�et edess�si rotkon ja huppup�isen henkil�n...\nMit� teet?");
			}
			}
			
			
}
	   
		/** Taso9 metodin kuvaus:<br><br>
		 * Jos pelaajan {@link #HP} on suurempi kuin 0 <code>if</code>-lauseen sis�ll� olevat asiat suoritetaan. <br>
		 * Taso9 metodi muuttaa tekstin Taso 9:ksi ja uudelleen nime�� painikkeet, jonka j�lkeen tulostaa taso9 kuvauksen. <br>
		 * Seuraavalle tasolle voidaan jatkaa valitsemalla tasovalinta painikkeiden avulla.
		 * @see GUI#teksti�
		 * @see GUI#tulosta
		 * @see GUI#painike1
		 * @see GUI#painike2
		 * @see GUI#painike3
		 * @see GUI#piilotapainike4
		 * @see #taso9valinta1
		 * @see #taso9valinta2
		 * @see #taso9valinta3
		 */
		static void taso9() {
			
			if (HP > 0) {
			
			GUI.teksti�("Taso 9"); 
			
			GUI.piilotapainike4();
			GUI.painike1("L�hde karkuun");
			GUI.painike2("Taistele rosvoja vastaan");
			GUI.painike3("Neuvottele rosvojen kanssa");
			
			GUI.tulosta("\n\nJatkat matkaasi isommalle polulle...\nKohtaat joukon pelottavan n�koisi� rosvoja, jotka himoitsevat aarrettasi...\nMit� teet?");
			}
	
}
		/** Taso10 metodin kuvaus:<br><br>
		 * Jos pelaajan {@link #HP} on suurempi kuin 0 <code>if</code>-lauseen sis�ll� olevat asiat suoritetaan. <br>
		 * Taso10 metodi muuttaa tekstin Taso 10:ksi ja uudelleen nime�� painikkeet, jonka j�lkeen tulostaa taso10 kuvauksen. <br>
		 * T�m� on pelin viimeinen taso pelaajan selviytyminen riippuu pelaajan valinnasta.
		 * @see GUI#teksti�
		 * @see GUI#tulosta
		 * @see GUI#painike1
		 * @see GUI#painike2
		 * @see GUI#painike3
		 * @see #taso10valinta1
		 * @see #taso10valinta2
		 * @see #taso10valinta3
		 */
		 static void taso10() {
			
			if (HP > 0) {
	
			GUI.teksti�("Taso 10"); 
		
			GUI.painike1("Omi aarre itsellesi");
			GUI.painike2("Jaa aarre kyl�l�isten kanssa");
			GUI.painike3("Piilota aarre");
			
			GUI.tulosta("\n\nOlet nyt miekkaseikkailun lopussa...\nJ�ljell� on viel� yksi valinta...\nSaavut kotikyl��si...\nMit� teet aarteellesi?");
			}
								
}
		
		
			/** Lopetus metodin kuvaus:<br><br>
			 * Lopetus metodi muuttaa tekstin haluatko yritt�� uudestaan, piilottaa turhat painikkeet ja muuttaa j�ljell� olevien painikkeiden tekstit vastaamaan valintaa.
			 * @see GUI#teksti�
			 * @see GUI#painike1
			 * @see GUI#painike2
			 * @see GUI#piilotapainike3
			 * @see GUI#piilotapainike4
			 * @see #lopetusvalinta1
			 * @see #lopetusvalinta2
			 */
		public static void lopetus() {
			
			GUI.teksti�("Haluatko yritt�� uudestaan?");
		
			GUI.piilotapainike3();
			GUI.piilotapainike4();
			GUI.painike1("Kyll�, tahdon yritt�� uudestaan");
			GUI.painike2("En, tahdon lopettaa pelin");
			
		
		}
		
		/** Arvo metodin kuvaus:<br><br>
		 * <code>int random</code> arpoo numeron 1-100 v�lilt� ja jos numero on 1-15 v�lilt� eli 15% kustuu {@link #peli}-metodia.
		 * @see #peli
		 */
			static void arvo() {	
				int random = (int) (Math.random() * 100 + 1);
				System.out.println("Random peli numero: " + random);
				if (random > 0 && random < 16) {
				peli();
				}
		  }
				
			
			/** Arvo metodin kuvaus:<br><br>
			 * <code>int random</code> arpoo numeron 1-3 v�lilt� jos {@link #arvo}-metodi kutsuu peli-metodia. <br>
			 * Jos <code>int random</code> 1 metodi kutsuu {@link RandomEvent#Monsterim�tt�(int)} metodia. <br>
			 * Jos <code>int random</code> 2 metodi kutsuu {@link RandomEvent#Vankilapako(int)} metodia. <br>
			 * Jos <code>int random</code> 3 metodi kutsuu {@link RandomEvent#Lampunhenki(int)} metodia.
			 * @see #peli
			 */
				static void peli() {
				int random = (int) (Math.random() * 3 + 1);

				if (random == 1){
				RandomEvent.Monsterim�tt�(random);
				}
				if (random == 2){
				RandomEvent.Vankilapako(random);
				}
				if (random == 3){
				RandomEvent.Lampunhenki(random);
				}
				}
				
				/** Vaikeustaso Getteri:<br><br>
				 * Hakee vaikeustason nykyisen arvon. <br>
				 * @return vaikeustason arvon
				 * @see #vaikeustaso
				 */
				public static int getVaikeustaso() {
					return vaikeustaso;
				}

				/** Vaikeustaso Setteri:<br><br>
				 * Asettaa vaikeustason arvon. <br>
				 * @see #vaikeustaso
				 * @param vaikeustaso m��ritetty vaikeustaso on uusi vaikeustaso
				 */
				public static void setVaikeustaso(int vaikeustaso) {
				MiekkaseikkailuV2.vaikeustaso = vaikeustaso;
				}

				
				/** Tason 1 Valinta 1 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 1 tasolta 1 h�nelle tulostetaan luokka kohtainen teksti. Pelaaja my�s menett�� 10 * {@link #vaikeustaso}:n verran vahinkoa<br>
				 * @see #vaikeustaso
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso1valinta1() {
				HP -= 10 * vaikeustaso;
				if (Hahmo.getLuokka().equals("Ritari")) {
				GUI.tulosta("\n\nL�hdet etel��n viev�lle polulle...\nV�h�n aikaa k�velty�si l�yd�t kaipaamasi miekan puun vierest�...\nKurotat ottaaksesi sen, mutta kompastut puunjuureen ja miekka viilt�� k�teesi haavan...\nOnneksesi miekka ei ollut hirve�n ter�v�...\nPoimit miekan ja jatkat matkaasi...");
				}
				if (Hahmo.getLuokka().equals("Taikuri")) {
				GUI.tulosta("\n\nL�hdet etel��n viev�lle polulle...\nV�h�n aikaa k�velty�si l�yd�t kaipaamasi taikasauvan puun vierest�...\nKurotat ottaaksesi sen, mutta kompastut puunjuureen ja oksa viilt�� k�teesi haavan...\nOnneksesi oksa ei ollut hirve�n ter�v�...\nPoimit taikasauvan ja jatkat matkaasi...");	
				}
				if (Hahmo.getLuokka().equals("Jousimies")) {
				GUI.tulosta("\n\nL�hdet etel��n viev�lle polulle...\nV�h�n aikaa k�velty�si l�yd�t kaipaamasi jousen puun vierest�...\nKurotat ottaaksesi sen, mutta kompastut puunjuureen ja puun oksa viilt�� k�teesi haavan...\nOnneksesi oksa ei ollut hirve�n ter�v�...\nPoimit jousen ja jatkat matkaasi...");	
				}
				GUI.tulosta("\nMenetit " + (10*vaikeustaso) + " HP:ta");
				return Hahmo.laskuri(HP);
				}

				/** Tason 1 Valinta 2 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 2 tasolta 1 h�nelle tulostetaan luokka kohtainen teksti.<br>
				 */
				public static void taso1valinta2() {
				if (Hahmo.getLuokka().equals("Ritari")) {	
				GUI.tulosta("\n\nL�hdet pohjoiseen viev�lle polulle...\nMiekkaa ja kilpe� ei kuitenkaan n�y...\nP��t�t jatkaa matkaasi t�st� huolimatta...");
				} 
				if (Hahmo.getLuokka().equals("Taikuri")) {	
				GUI.tulosta("\n\nL�hdet pohjoiseen viev�lle polulle...\nTaikasauvaa tai taikakirjaa ei kuitenkaan n�y...\nP��t�t jatkaa matkaasi t�st� huolimatta...");
				}
				if (Hahmo.getLuokka().equals("Jousimies")) {	
				GUI.tulosta("\n\nL�hdet pohjoiseen viev�lle polulle...\nJuosia ja nuolia ei kuitenkaan n�y...\nP��t�t jatkaa matkaasi t�st� huolimatta...");
				} 
				}
				
				/** Tason 1 Valinta 3 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 3 tasolta 1 h�nelle tulostetaan luokka kohtainen teksti. Pelaajalle annetaan lis�� 25 {@link #HP}:ta<br>
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso1valinta3() {
				HP += 25;
				if (Hahmo.getLuokka().equals("Ritari")) {
				GUI.tulosta("\n\nL�hdet it��n viev�lle polulle...\nHetken matkattuasi n��t esineen ojassa...\nKatsot ojaan ja l�yd�t etsim�si kilven...\nT�m� parantaa todenn�k�isyytt�si selviyty�\n+25 HP");
				}
				if (Hahmo.getLuokka().equals("Taikuri")) {
				GUI.tulosta("\n\nL�hdet it��n viev�lle polulle...\nHetken matkattuasi n��t esineen ojassa...\nKatsot ojaan ja l�yd�t etsim�si taikakirjan...\nT�m� parantaa todenn�k�isyytt�si selviyty�\n+25 HP");
				}
				if (Hahmo.getLuokka().equals("Jousimies")) {
				GUI.tulosta("\n\nL�hdet it��n viev�lle polulle...\nHetken matkattuasi n��t esineen ojassa...\nKatsot ojaan ja l�yd�t etsim�si nuolet...\nT�m� parantaa todenn�k�isyytt�si selviyty�\n+25 HP");
				}
				return Hahmo.laskuri(HP);
				}
				
				/** Tason 2 Valinta 1 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 1 tasolta 2 h�nelle tulostetaan luokka kohtainen teksti. Pelaaja my�s menett�� 20 * {@link #vaikeustaso}:n verran vahinkoa<br>
				 * @see #vaikeustaso
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso2valinta1() {
				HP -= 10 * vaikeustaso;
				GUI.tulosta("\n\nAijai n�ytt�� silt� ett�, kompastuit h�tik�idess�si kiveen...");
				GUI.tulosta("\nMenetit " + (10 * vaikeustaso) + " HP:ta");
				return Hahmo.laskuri(HP);
				}
				
				/** Tason 2 Valinta 2 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 2 tasolta 2 h�nelle tulostetaan luokka kohtainen teksti.<br>
				 * @see #vaikeustaso
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 */
				public static void taso2valinta2() {
				GUI.tulosta("\n\nL�hdet rennosti h�lkk��m��n...\nN�et hirvi�n takanasi ja katsot sit� silmiin...\nHirvi� kavahtaa rohkeuttasi ja j�tt�� sinut rauhaan...");	
				}
				
				
				/** Tason 2 Valinta 3 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 3 tasolta 2 h�nelle tulostetaan luokka kohtainen teksti. Pelaajan {@link #HP} m��ritell��n my�s 0:ksi<br>
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso2valinta3() {
				HP = 0;
				GUI.tulosta("\n\nAijai! Tyhmyytesi tulee maksaamaan sinulle kalliisti...\nN�et takaasi juoksevan hirvi�n ja se tappaa sinut mahdollisimman raa�alla tavalla...\nT�m� oli niin kamala tapahtuma, jota en rupea kuvailemaan tarkemmin... Sinulta voisi menn� y�unet. :)");	
				return Hahmo.laskuri(HP);
				}
				
				/** Tason 3 Valinta 1 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 1 tasolta 3 h�nelle tulostetaan luokka kohtainen teksti. Pelaajalle annetaan 25 {@link #HP}:ta<br>
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso3valinta1() {
				HP += 25;
				GUI.tulosta("\n\nOnnistuit l�yt�m��n kalan...\nPaistoit sen tekem�ll�si nuotiolla...\nVoi juku, ett� kala n�ytt�� hyv�lt�...\n+25 HP:ta");	
				return Hahmo.laskuri(HP);
				}
				
				/** Tason 3 Valinta 2 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 2 tasolta 3 h�nelle tulostetaan luokka kohtainen teksti. Pelaajalle annetaan 10 {@link #HP}:ta<br>
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso3valinta2() {
				HP += 10;
				GUI.tulosta("\n\nOtit h�rpyn vedest�...\nVesi maistui raikkaalta juoksun j�lkeen...\n+10 HP:ta");	
				return Hahmo.laskuri(HP);
				}
				
				/** Tason 3 Valinta 3 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 3 tasolta 3 h�nelle tulostetaan luokka kohtainen teksti.<br>
				 * @see GUI#tulosta
				 */
				public static void taso3valinta3() {
				GUI.tulosta("\n\nPuro ei siis kiinnosta sinua...\nJatkat matkaasi eteenp�in purosta v�litt�m�tt�...");	
				}
				
				/** Tason 4 Valinta 1 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 1 tasolta 4 h�nelle tulostetaan luokka kohtainen teksti. Pelaaja my�s menett�� 20 * {@link #vaikeustaso}:n verran vahinkoa<br>
				 * @see #vaikeustaso
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso4valinta1() {
				HP -= 20 * vaikeustaso;
				GUI.tulosta("\n\nMusta Ritari on kunniallinen ja antaa sinulle taisteluv�lineen...\nAloitatte taistelun ja pitk�n taistelun j�lkeen voitat Mustan Ritarin...\nLy�t h�nen p��ns� poikki...\nOlet v�synyt taistelusta ja huomaat saaneesi taistelusta haavoja...");
				GUI.tulosta("\nMenetit " + (20*vaikeustaso) + " HP:ta");
				return Hahmo.laskuri(HP);
				}
				
				/** Tason 4 Valinta 2 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 2 tasolta 4 h�nelle tulostetaan luokka kohtainen teksti. Pelaajan {@link #HP}:t muutetaan 0:ksi<br>
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso4valinta2() {
				HP = 0;
				GUI.tulosta("\n\nL�hdit juoksemaan karkuun...\nMusta Ritari ei kuitenkaan tyk�nnyt t�st�...\nH�n l�hti per��si ja heitti tikarilla sinua takaraivoon...\nNo ainakin yritit.");	
				return Hahmo.laskuri(HP);
				}
				
				
				/** Tason 4 Valinta 3 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 3 tasolta 5 h�nelle tulostetaan luokka kohtainen teksti.<br>
				 * @see GUI#tulosta
				 */
				public static void taso4valinta3() {
				GUI.tulosta("\n\nKyselit Mustalta Ritarilta kuulumisia ja huijasit h�nt� vanhanaikaisella h�m�yksell�...\nKolautit h�nt� nopeasti kivell� p��h�n...\nOtit Mustan Ritarin miekan ja l�vistit h�net monta kertaa ja viel� l�it h�nen p��ns� irti (FATALITY)...");	
				}
				/** Tason 5 Valinta 1 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 1 tasolta 5 h�nelle tulostetaan luokka kohtainen teksti. Pelaajan {@link #HP}:t muutetaan 0:ksi<br>
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso5valinta1() {
				HP = 0;
				GUI.tulosta("\n\nY�ll� Valkoinen Ritari saapui lepopaikalle...\nOli jo liian my�h�ist�...\nValkoinen Ritari oli saanut selville, ett� tapoit h�nen kaverinsa...\nH�n p��tti kostaa kaverinsa surman ja tappoi sinut kylm�n rauhallisesti...");	
				return Hahmo.laskuri(HP);
				}
				/** Tason 5 Valinta 2 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 2 tasolta 5 h�nelle tulostetaan luokka kohtainen teksti. Pelaaja my�s menett�� 25 * {@link #vaikeustaso}:n verran vahinkoa<br>
				 * @see #vaikeustaso
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso5valinta2() {
				HP -= 25 * vaikeustaso;
				GUI.tulosta("\n\nTutkit leiripaikkaa nopeasti...\nMutta tiput vahingossa ansaan...\nJonka luultavasti Musta Ritari oli viritt�nyt sinne...\nSatutat itsesi, etk� halua etsi� enemp��...\nNouset ansasta ja jatkat matkaa v�h�n matkan p��h�n...\nTeet oman leiripaikan ja menet nukkumaan.");
				GUI.tulosta("\nMenetit " + (25*vaikeustaso) + " HP:ta");
				return Hahmo.laskuri(HP);
				}
				/** Tason 5 Valinta 3 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 3 tasolta 5 h�nelle tulostetaan luokka kohtainen teksti. Pelaajalle annetaan 40 tai 80 HP:ta luokasta riippuen.<br>
				 * Jos hahmon {@link Hahmo#luokka} on taikuri h�n saa 80 lis�el�m�� ja h�nelle tulostetaan luokkakohtainen teksti.
				 * @see #vaikeustaso
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso5valinta3() {
				if (Hahmo.getLuokka().equals("Taikuri")) {	
				HP += 80;
				GUI.tulosta("\n\nTutkit leiripaikkaa tarkasti...\nHuomaat ansan, etk� laukaise sit�...\nLeiripaikasta l�yd�t taikajuoman...\nAjattelet, ett� on hyv� idea juoda se...\nT�m�n j�lkeen jatkoit v�h�n matkan p��h�n Mustan Ritarin leiripaikasta...\nTeet oman leiripaikan ja menet nukkumaan.\n+80 HP:ta");	
				} else {	
				HP += 40;
				GUI.tulosta("\n\nTutkit leiripaikkaa tarkasti...\nHuomaat ansan, etk� laukaise sit�...\nLeiripaikasta l�yd�t taikajuoman...\nAjattelet, ett� on hyv� idea juoda se...\nT�m�n j�lkeen jatkoit v�h�n matkan p��h�n Mustan Ritarin leiripaikasta...\nTeet oman leiripaikan ja menet nukkumaan.\n+40 HP:ta");	
				}
				return Hahmo.laskuri(HP);
				}
				
				
				/** Tason 5 Valinta 4 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 4 tasolta 5 h�nelle tulostetaan luokka kohtainen teksti.<br>
				 * @see GUI#tulosta
				 */
				public static void taso5valinta4() {
				GUI.tulosta("\n\nJostain syyst� et ole seikkailun haluinen...\nP��t�t jatkaa matkaasi v�h�n matkan p��h�n...\nTeet oman leiripaikan ja menet nukkumaan.");	
				}
				
				/** Tason 6 Valinta 1 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 1 tasolta 6 h�nelle tulostetaan luokka kohtainen teksti.<br>
				 * @see GUI#tulosta
				 */
				public static void taso6valinta1() {
				GUI.tulosta("\n\nHiivit niin hiljaa, ettei Valkoinen Ritari kuule sinua...\nN�et Valkoisen Ritarin, eik� h�n huomaa sinua...");	
				}
				/** Tason 6 Valinta 2 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 2 tasolta 6 h�nelle tulostetaan luokka kohtainen teksti. Pelaajan {@link #HP}:t m��ritet��n 0:ksi<br>
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso6valinta2() {
				HP = 0;
				GUI.tulosta("\n\nL�hdit k�velem��n huudon suuntaan...\nMatkalla astut monen risun p��lle...\nMenet leiripaikalle, siell� ei kuitenkaan ole ket��n...\nYht�kki� kuulet askelia takaasi...\nEt ehdi edes vilkaista, kun miekka jo l�vist�� syd�mesi (FATALITY)...");	
				return Hahmo.laskuri(HP);
				}
				
				/** Tason 6 Valinta 3 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 3 tasolta 6 h�nelle tulostetaan luokka kohtainen teksti. Pelaajan {@link #HP}:t m��ritet��n 0:ksi<br>
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso6valinta3() {
				HP = 0;
				GUI.tulosta("\n\nL�hdet juoksemaan huudon suuntaan ja hy�kk��t Valkoisen Ritarin kimppuun...\nAloittatte eeppisen taistelun...\nViimein onnistut nujertamaan Valkoisen Ritarin...\nHuonoksi onneksesi huomaat olosi heikoksi...\nV�h�n ajan kuluttua menet�t n�k�si ja syd�mesi alkaa ly�d� hitaammin...\nValkoinen Ritari oli k�ytt�nyt miekassaan myrkky�...");	
				return Hahmo.laskuri(HP);
				}
				
				/** Tason 6 Valinta 4 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 4 tasolta 6 h�nelle tulostetaan luokka kohtainen teksti. Pelaaja my�s menett�� 5 * {@link #vaikeustaso}:n verran vahinkoa<br>
				 * @see #vaikeustaso
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso6valinta4() {
				HP -= 5 * vaikeustaso;
				GUI.tulosta("\n\nL�hdet ry�mim��n huudon suuntaan ja ter�v�t kivet sattuttavat sinua...\nN�et kumminkin viel� Valkoisen Ritarin...\nIhme kyll�, Valkoinen Ritari ei kuitenkaan huomaa tai kuule sinua sinua...");	
				GUI.tulosta("\nMenetit " + (5*vaikeustaso) + " HP:ta");
				return Hahmo.laskuri(HP);
				}
				
				
				/** Tason 7 Valinta 1 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 1 tasolta 7 h�nelle tulostetaan luokka kohtainen teksti. Pelaaja my�s menett�� 40 * {@link #vaikeustaso}:n verran vahinkoa<br>
				 * Jos pelaaja j�� henkiin h�n l�yt�� my�s aarteen, jonka arvo on 500 000 kultaa.
				 * @see #vaikeustaso
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @see Hahmo#getKulta
				 * @see Hahmo#setKulta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso7valinta1() {
				HP -= 40 * vaikeustaso;
				GUI.tulosta("\n\nKuulet huutoa...\nHuomaat, ett� Valkoinen Ritari taistelee urheasti aiemmin tapaamaasi hirvi�t� vastaan...\nP��t�t menn� auttamaan h�nt�...\nValkoinen Ritari ja hirvi� kuolevat taistelussa...\nSelvi�t hengiss�, mutta taistelusta saamat haavasi n�ytt�v�t vakavilta...");
				GUI.tulosta("\nMenetit " + (40*vaikeustaso) + " HP:ta");
				if (HP > 0) {
				GUI.tulosta("\nL�yd�t my�s aarrearkun, joka on t�ynn� kultarahoja arviot sen arvoksi noin 500 000.");	
				Hahmo.setKulta(Hahmo.getKulta() + 500000);
				}
				return Hahmo.laskuri(HP);
				}
				
				
				/** Tason 7 Valinta 2 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 2 tasolta 7 h�nelle tulostetaan luokka kohtainen teksti. Pelaaja saa my�s 500 000 kultarahaa.<br>
				 * @see GUI#tulosta
				 * @see Hahmo#getKulta
				 * @see Hahmo#setKulta
				 */
				public static void taso7valinta2() {
				GUI.tulosta("\n\nOdotat ja odotat...\nV�h�n ajan p��st� kuulet useita avunhuutoja...\nL�hdit tutkimaan luolaa ja l�yd�t kuolleen Valkoisen Ritarin ja pahasti haavoittuneen hirvi�n...\nP��t�t lopettaa hirvi�n tuskat...\nL�yd�t my�s aarrearkun, joka on t�ynn� kultarahoja arviot sen arvoksi noin 500 000.");
				Hahmo.setKulta(Hahmo.getKulta() + 500000);
				}
				
				/** Tason 7 Valinta 3 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 3 tasolta 7 h�nelle tulostetaan teksti. Pelaajan {@link #HP}:t m��ritet��n 0:ksi<br>
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso7valinta3() {
				HP = 0;
				GUI.tulosta("\n\nL�hdet jatkamaan matkaasi...\nValitettavasti pelist� l�ytyi bugi...\nTiput kartan reunalta varmaan tuhoosi...");	
				return Hahmo.laskuri(HP);	
				}
				
				
				/** Tason 8 Valinta 1 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 1 tasolta 8 h�nelle tulostetaan teksti.<br>
				 * Jos pelaaja on taikuri h�n tunnistaa tuntemattoman henkil�n haltiaksi. <br>
				 * Jos pelaajan luokka on jokin muu kuin taikuri h�n menett�� 25 * {@link #vaikeustaso} verran vahinkoa.
				 * @see #vaikeustaso
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso8valinta1() {
				
				if (Hahmo.getLuokka().equals("Taikuri")) {
				GUI.tulosta("\n\nYrit�t potkaista haltian rotkoon...\nJalkasi kuitenkin menee suoraan haltian l�pi...\nHaltia p��tt�� kirota sinut, koska yritit potkaista h�nt�...\nHaltian kirous ei kuitenkaan tehoa sinuun, koska olet Taikuri...");	
				} else {
				HP -= 25 * vaikeustaso;
				GUI.tulosta("\n\nYrit�t potkaista tuntemattoman henkil�n rotkoon...\nJalkasi kuitenkin menee suoraan huppup�isen henkil�n l�pi...\nHuomaat h�nen olevan haltia...\nHaltia p��tt�� kirota sinut, koska yritit potkaista h�nt�...");
				GUI.tulosta("\nMenetit " + (25*vaikeustaso) + " HP:ta");	
				}
				return Hahmo.laskuri(HP);
				}
				
				
				/** Tason 8 Valinta 2 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 2 tasolta 8 h�nelle tulostetaan teksti. Pelaajan kulta my�s kaksinkertaistetaan<br>
				 * Jos pelaaja on taikuri h�n tunnistaa tuntemattoman henkil�n haltiaksi. <br>
				 * Jos pelaajan luokka on jokin muu kuin Taikuri h�n saa 25 lis�el�m��. <br>
				 * Muussa tapauksessa pelaajalle annetaan 50 lis�el�m��. 
				 * @see #vaikeustaso
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @see Hahmo#getKulta
				 * @see Hahmo#setKulta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso8valinta2() {
				
				Hahmo.setKulta(Hahmo.getKulta() * 2);
				if (Hahmo.getLuokka().equals("Taikuri")) {
				GUI.tulosta("\nP��t�t olla jalo ja annat aarteesi haltialle...\nHaltia sanoo jaloutesi tekev�n h�neen suuren vaikutuksen ja tuplaa aarteesi ja antaa sinulle taikajuoman...\nJuotuasi juoman tunnet itsesi vahvemmaksi...\n+50 HP:ta");
				HP += 50;
				} else {
				GUI.tulosta("\nP��t�t olla jalo ja annat aarteesi huppup�iselle henkil�lle...\nHuppup�inen henkil� osoittautuukin haltiaksi...\nHaltia sanoo jaloutesi tekev�n h�neen suuren vaikutuksen ja tuplaa aarteesi ja antaa sinulle taikajuoman...\nJuotuasi juoman tunnet itsesi vahvemmaksi...\n+25 HP:ta");
				HP += 25;
				}
				return Hahmo.laskuri(HP);
				}
				
				
				/** Tason 8 Valinta 3 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 3 tasolta 8 h�nelle tulostetaan teksti.<br>
				 * Jos pelaaja on taikuri h�n tunnistaa tuntemattoman henkil�n haltiaksi. <br>
				 * @see GUI#tulosta
				 */
				public static void taso8valinta3() {
					if (Hahmo.getLuokka().equals("Taikuri")) {
						GUI.tulosta("\nP��t�t kuitenkin viisaammaksi kiert�� rotkon ja siell� olevan haltian...");		
					} else {	
						GUI.tulosta("\nP��t�t kuitenkin viisaammaksi kiert�� rotkon ja salaper�isen huppup�isen henkil�n...\nSilti j��t miettim��n kuka h�n oli...");	
					}
					}
				
				
				/** Tason 8 Valinta 4 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 4 tasolta 8 h�nelle tulostetaan teksti.<br>
				 * Jos pelaaja on taikuri h�n tunnistaa tuntemattoman henkil�n haltiaksi. <br>
				 * Jos pelaajan luokka on jokin muu kuin taikuri h�nen HP m��ritet��n 0:ksi ja menett�� kultansa.
				 * @see #vaikeustaso
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @see Hahmo#setKulta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso8valinta4() {
			
				if (Hahmo.getLuokka().equals("Taikuri")) {
				GUI.tulosta("\nTaitavana magian mestarina huomaat aarteessa olevan piilotettuja taikoja...\nJos heitt�isit aarteen rotkoon k�tesi liimautuisivat arkkuun kiinni ja tippuisit arteen mukana rotkoon...\nP��t�t viisaimmaksi pit�� aarteen...");	
				} else {
				HP = 0;
				Hahmo.setKulta(0);
				GUI.tulosta("\nYrit�t heitt�� aarteen rotkoon, mutta k�tesi liimautuvat aarrearkkuun...\nTunnet aarteen vet�v�n sinua rotkoon p�in...\nTiput aarteen kanssa rotkoon ja kuulet ylh��lt� naurua...\nOlisikohan t�m� ollut huppup�isen henkil�n tekosia ajattelit, tippuessasi mustaan rotkoon...");		
				}
				return Hahmo.laskuri(HP);
				}
				
				
				/** Tason 9 Valinta 1 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 1 tasolta 9 h�nelle tulostetaan teksti.<br>
				 * Jos pelaajan luokka on jokin muu kuin jousimies h�n menett�� {@link Hahmo#kulta} /3 verran kultaansa.
				 * @see GUI#tulosta
				 */
				public static void taso9valinta1() {
				if (Hahmo.getLuokka().equals("Jousimies")) {	
				GUI.tulosta("\n\nL�hdet juoksemaan rosvoista poisp�in...\nOnnistut pakenemaan rosvoja ja ketteryytesi ansiosta et tiputa yht��n rahaa paon aikana");		
				} else {
				GUI.tulosta("\n\nL�hdet juoksemaan rosvoista poisp�in...\nOnnistut pakenemaan rosvoja, mutta osa kullastasi tippuu matkalle...");	
				Hahmo.setKulta(Hahmo.getKulta() / 3);
				}
				}
				
				/** Tason 9 Valinta 2 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 2 tasolta 9 h�nelle tulostetaan teksti.<br>
				 * Jos pelaajan luokka on jokin muu kuin jousimies h�n ottaa 15 *{@link #vaikeustaso} verran vahinkoa.
				 * @see #vaikeustaso
				 * @see Hahmo#laskuri
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso9valinta2() {
				if (Hahmo.getLuokka().equals("Jousimies")) {
				GUI.tulosta("\n\nTaistelet rosvoja vastaan urheasti...\nKetteryytesi ansiosta rosvoista ei ole sinulle vastusta");		
				} else {
				HP -= 15 * vaikeustaso;
				GUI.tulosta("\n\nTaistelet rosvoja vastaan urheasti...\nNujerrettuasi rosvot huomaat saaneesi taistelusta jonkin verran osumia...");
				GUI.tulosta("\nMenetit " + (15*vaikeustaso) + " HP:ta");	
				}
				return Hahmo.laskuri(HP);
				}
				
				
				/** Tason 9 Valinta 3 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 3 tasolta 9 h�nelle tulostetaan teksti.<br>
				 * Jos pelaajan luokka on jokin muu kuin jousimies h�nen {@link Hahmo#kulta}nsa puolitetaan. <br>
				 * Muussa tapauksessa arvotaan <code>int kulta</code> 1-10 000 v�lilt� ja lis�t��n pelaajan {@link Hahmo#kulta}a sen verran.
				 * @see Hahmo#getKulta
				 * @see Hahmo#setKulta
				 * @see GUI#tulosta
				 */
				public static void taso9valinta3() {
				int kulta = (int) (Math.random() * 10000 + 1);
				if (Hahmo.getLuokka().equals("Jousimies")) {
				GUI.tulosta("\n\nP��t�t neuvotella rosvojen kanssa...\nRosvot olivat kuitenkin kovia neuvottelemaan...\nLopulta he suostuvat j�tt�m��n sinut rauhaan, jos otat vastaan heid�n varastamansa kullan vastaan...\nKyll� luit oikein, koska olit niin viekas ja k�ytit k��nteispsykologiaa he tahtovat suorastaan antaa rahansa sinulle...");	
				Hahmo.setKulta(Hahmo.getKulta() + kulta);
				GUI.tulosta("\nRosvot antoivat sinulle " + kulta + " kultarahaa.");
				} else {
				Hahmo.setKulta(Hahmo.getKulta() / 2);
				GUI.tulosta("\n\nP��t�t neuvotella rosvojen kanssa...\nRosvot olivat kuitenkin kovia neuvottelemaan...\nLopulta he suostuvat j�tt�m��n sinut rauhaan, jos annat heille puolet aarteestasi...\nP��t�t suostua heid�n pyynt��ns�...");	
				}
				}
				
				/** Tason 10 Valinta 1 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 1 tasolta 10 h�nelle tulostetaan teksti.<br>
				 * Jos pelaajan luokka on taikuri, h�n voittaa pelin. <br>
				 * Jos pelaajan luokka on jokin muu kuin taikuri h�nen HP:nsa m��ritell��n 0:ksi<br>
				 * @see Hahmo#setKulta
				 * @see GUI#tulosta
				 * @return palauttaa p�ivittyneen {@link #HP}:n {@link Hahmo#laskuri}:in
				 */
				public static int taso10valinta1() {
					if (Hahmo.getLuokka().equals("Taikuri")) {
					GUI.tulosta("\n\nOmittuasi aarteen itsellesi huomaat arkkuun piilotetusta taiasta, joka aktivoituu ahneudesta...\nMagian mestarina purat taian ja omit aarteen itsellesi\n\nOnneksi olkoon! Voitit pelin onnittellut sinulle...\nOlet nyt ahne miekkamestari.");	
					} else {
					HP = 0;
					Hahmo.setKulta(0);
					GUI.tulosta("\n\nOmittuasi aarteen itsellesi...\nLuulet olevasi turvassa, mutta tulet hulluksi ihaillessasi aarretta...\nAhneutesi aktivoi aarteen kirouksen...\nT�st� syyst� ty�nn�t rahat kurkkuusi ja tukehdut niihin (FATALITY)...");
					}
					return Hahmo.laskuri(HP);
				}
				
				/** Tason 10 Valinta 2 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 2 tasolta 10 h�nelle tulostetaan teksti.<br>
				 * Pelaaja voittaa pelin ja h�nen kultansa nollataan. <br>
				 * @see Hahmo#setKulta
				 * @see GUI#tulosta
				 */
				public static void taso10valinta2() {
				GUI.tulosta("\n\nOnneksi olkoon! Voitit pelin onnittellut sinulle...\nOlet nyt jalo miekkamestari ja kyl�l�iset rakastavat sinua.");	
				Hahmo.setKulta(0);
				}
				
				/** Tason 10 Valinta 3 metodi:<br><br>
				 * Kun pelaaja valitsee valinnan 3 tasolta 10 h�nelle tulostetaan teksti.<br>
				 * Pelaaja voittaa pelin ja h�nen kultansa nollataan. <br>
				 * @see Hahmo#setKulta
				 * @see GUI#tulosta
				 */
				public static void taso10valinta3() {
				GUI.tulosta("\n\nOnneksi olkoon! Voitit pelin onnittellut sinulle...\nOlet nyt ahne miekkamestari.");
				Hahmo.setKulta(0);
				}
				
				/** Lopetusvalinta1 metodi:<br><br>
				 * Kutsuu uusipeli metodia.<br>
				 * @see GUI#uusipeli
				 */
				public static void lopetusvalinta1() {
				GUI.uusipeli();
				}
				/** Lopetusvalinta2 metodi:<br><br>
				 * Kutsuu System.exit() metodia joka sulkee ohjelman<br>
				 */
				public static void lopetusvalinta2() {
				System.exit(0);	
				}
				
				/** Hahmovalinta1 metodi:<br><br>
				 * Kutsuu Hahmo luokan ritari metodia ja tulostaa k�ytt�j�lle tekstin<br>
				 * @see Hahmo#ritari
				 * @see GUI#tulosta
				 */
				public static void hahmovalinta1() {
					Hahmo.ritari();
					GUI.tulosta("\n\nHaluat olla siis Ritari? Oletko aivan varma?");
					}
				
				/** Hahmovalinta2 metodi:<br><br>
				 * Kutsuu Hahmo luokan taikuri metodia ja tulostaa k�ytt�j�lle tekstin<br>
				 * @see Hahmo#taikuri
				 * @see GUI#tulosta
				 */
				public static void hahmovalinta2() {
					Hahmo.taikuri();
					GUI.tulosta("\n\nHaluat olla siis Taikuri? Oletko aivan varma?");
					}
				
				/** Hahmovalinta3 metodi:<br><br>
				 * Kutsuu Hahmo luokan jousimies metodia ja tulostaa k�ytt�j�lle tekstin<br>
				 * @see Hahmo#jousimies
				 * @see GUI#tulosta
				 */
				public static void hahmovalinta3() {
					Hahmo.jousimies();
					GUI.tulosta("\n\nHaluat olla siis Jousimies? Oletko aivan varma?");
					}
				
}